# NetPulse - Project report content

## Abstract
NetPulse is a hybrid cloud connectivity monitoring system that continuously verifies whether an on-premises
network can communicate with a cloud network hosted on AWS. A Python FastAPI backend performs real ICMP ping tests,
measures response time and packet loss, stores every result in a database and raises alerts when the connection is
lost, restored or slow. A React dashboard displays live status, analytics, history and alerts. An ESP32
microcontroller with a push button and two LEDs lets a user trigger a test physically: the request travels through
AWS IoT Core using MQTT over TLS, the backend performs the test, and the result lights a green or red LED while the
dashboard updates in real time. The project demonstrates practical cloud networking, IoT and full-stack
development at low cost.

## Problem statement
Organizations running hybrid infrastructure depend on connectivity between local networks and cloud networks.
When that link fails, services stop, yet failures are often noticed only when users complain. Commercial monitoring
tools are expensive and complex for small teams and students, and they rarely give an immediate physical indicator.
There is a need for a simple, low-cost system that tests hybrid connectivity with real measurements, records history,
alerts on failure and provides both a web dashboard and a physical status device.

## Objectives
1. Perform real connectivity tests (not simulated) between an on-premises host and an AWS VPC endpoint.
2. Measure response time and packet loss and compute availability and a health score.
3. Store test history and alerts, and visualize trends with charts.
4. Provide a responsive web dashboard that updates in real time.
5. Integrate an ESP32 device that triggers tests and shows results with LEDs.
6. Use AWS IoT Core (MQTT, device certificates, TLS) for secure device communication.
7. Keep the solution affordable and demonstrable.

## Scope
**In scope:** ICMP reachability and latency testing of one configurable target, history, analytics, alerts, settings,
ESP32 trigger through AWS IoT Core, simulated hybrid link using EC2 in a VPC (optional WireGuard tunnel).
**Out of scope:** a production Site-to-Site VPN (described conceptually), multi-user authentication, monitoring many
targets, application-layer (HTTP/TCP) checks, e-mail/SMS notifications. These are listed as future enhancements.

## Software requirements
Windows/macOS/Linux; Python 3.10+; FastAPI, Uvicorn, paho-mqtt, SQLite; Node.js 18+, React 18, Vite, Recharts,
lucide-react; Arduino IDE with ESP32 board package and PubSubClient; AWS account (IoT Core, VPC, EC2); modern browser.

## Hardware requirements
ESP32 development board with USB cable; push button; green LED; red LED; two 220 ohm resistors; breadboard and
jumper wires; Wi-Fi network allowing outbound port 8883; a laptop or PC.

## Methodology (summary)
Phase 1 UI, 2 backend, 3 integration, 4 real ping and history, 5 analytics and alerts, 6 ESP32, 7 AWS IoT Core,
8 testing and demonstration (see README and `01_design.md`).

## Testing documentation
| ID | Test | Steps | Expected result | Result |
|---|---|---|---|---|
| T1 | Reachable target | Target = reachable IP, click Test | Green, real ms shown, row in History | |
| T2 | Unreachable target | Target = 203.0.113.1, click Test | Red, "No reply" reason, critical alert | |
| T3 | Recovery alert | After T2 set a reachable target, test | "Connection restored" alert | |
| T4 | Input validation | Target = `8.8.8.8; dir` | Save rejected with clear message | |
| T5 | Invalid hostname | Target = `bad host!` | Save rejected | |
| T6 | Timeout handling | Target = non-existing IP, timeout 500 ms | Fails within a few seconds, no crash | |
| T7 | Auto monitoring | Enable, interval 10 s | New rows every ~10 s labelled "Auto monitor" | |
| T8 | High-latency alert | Set limit to 10 ms, test a slower target | Warning alert once | |
| T9 | Statistics | Run 5 tests (3 ok, 2 failed) | Total 5, success 3, failed 2, availability 60% | |
| T10 | CSV export | History > Export CSV | File opens with all rows | |
| T11 | Backend offline | Stop backend | Red banner shown, UI does not crash | |
| T12 | Live update | Open two browser tabs, test in one | Other tab updates via WebSocket | |
| T13 | MQTT bridge | Publish request in AWS MQTT test client | Result message received, history row "ESP32" | |
| T14 | ESP32 success | Press button, reachable target | Green LED on, dashboard updated | |
| T15 | ESP32 failure | Press button, unreachable target | Red LED on, dashboard updated | |
| T16 | Backend down + ESP32 | Stop backend, press button | Red LED after 15 s timeout | |
(Fill the "Result" column during your demo with Pass/Fail and a screenshot reference.)

## Advantages
Real measurements; low cost (free-tier cloud + about 500 rupees of hardware); easy to understand and extend;
instant physical indicator; secure device communication; works on any OS; open technologies.

## Real-world applications
Branch-office-to-cloud link monitoring; data-center and edge-site health checks; network operations center wall
indicators; remote labs and classrooms; IoT gateways verifying cloud reachability; disaster-recovery link checks.

## Future enhancements
TCP/HTTP checks, multiple targets, e-mail/SMS/Telegram alerts through AWS SNS, user login, cloud-hosted
dashboard, real Site-to-Site VPN, OLED display on ESP32, over-the-air updates.

## Conclusion
NetPulse shows that hybrid connectivity monitoring can be implemented with simple, affordable components while using
real network measurements, secure cloud messaging and a professional dashboard.
