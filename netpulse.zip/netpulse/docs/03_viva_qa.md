# NetPulse - Viva questions and answers

**1. What is NetPulse?** A hybrid cloud connectivity monitor. It checks with a real ping whether an on-premises
network can reach an AWS VPC, shows status, response time, history, analytics and alerts, and has an ESP32 button
with LEDs to trigger and show the result.

**2. What is a hybrid cloud?** A setup combining on-premises infrastructure with a public cloud, connected by a
network link such as a VPN, so both act as one environment.

**3. How do you test connectivity?** The backend runs the operating system's `ping` command (3 packets) using Python
`subprocess`, parses the reply times, and decides reachable if at least one reply arrives.

**4. Are the results real or random?** Real. No random numbers are used. The only simulated element is the hybrid
link (internet instead of a paid VPN), which the dashboard labels.

**5. How did you prevent command injection?** The target is validated as an IP address or hostname with a strict
pattern, and `subprocess.run` receives a list of arguments with no `shell=True`, so special characters are never
interpreted as commands.

**6. What is ICMP?** Internet Control Message Protocol, used by ping (echo request/reply) for reachability and
latency. AWS blocks it by default, so we add an inbound ICMP rule to the security group.

**7. Why FastAPI?** It is fast, simple, gives automatic API documentation at `/docs`, supports WebSockets and uses
Python type hints for validation.

**8. Why WebSocket and polling?** WebSocket pushes new results instantly (for example when the ESP32 button is
pressed). Polling every 15 s is the fallback if the socket drops.

**9. What is MQTT?** A lightweight publish/subscribe protocol for IoT. Devices publish to topics and subscribe to
topics through a broker. It suits small devices and unreliable networks.

**10. What does AWS IoT Core do?** It is a managed MQTT broker with device identity (certificates), policies and
TLS. It lets the ESP32 and backend exchange messages without a server of our own.

**11. How is communication secured?** TLS on port 8883 with mutual authentication: the device proves identity with
its X.509 certificate and checks AWS using the Amazon Root CA. IoT policies allow each client only its own topics.

**12. Why must the ESP32 sync its clock?** Certificates have validity dates. Without correct time TLS validation
fails, so the firmware gets the time over NTP before connecting.

**13. What are your MQTT topics?** `netpulse/esp32-01/test/request` (ESP32 to backend) and
`netpulse/esp32-01/test/result` (backend to ESP32).

**14. What is request_id for?** It links a result to the button press that caused it, so the ESP32 ignores stale
or unrelated messages.

**15. Why do the LEDs need resistors?** To limit current. An ESP32 pin gives 3.3 V; without a 220 ohm resistor the
LED and the pin can be damaged.

**16. What is INPUT_PULLUP?** An internal resistor that holds the button pin HIGH. Pressing the button connects it
to GND (LOW), so no external resistor is required.

**17. What is a VPC?** A Virtual Private Cloud: your own isolated virtual network in AWS with subnets, route tables
and security groups.

**18. What is a Site-to-Site VPN?** An IPsec tunnel between a customer gateway (your router) and an AWS Virtual
Private Gateway so private IP traffic flows securely between on-premises and the VPC. We describe it but simulate
the link because it is billed hourly and needs compatible hardware.

**19. How is the health score calculated?** 70% availability over the last 50 tests plus 30% speed score
(`100 - average_ms / 3`, minimum 0).

**20. When are alerts created?** On status changes: connection lost (critical), connection restored (success), and
when latency first exceeds the configured limit (warning). Repeated failures do not spam new alerts.

**21. Why SQLite?** Zero configuration, a single file, enough for this scale. It could be replaced by PostgreSQL or
AWS DynamoDB for production.

**22. Why not use Lambda?** The backend already performs the test and is subscribed to MQTT. Fewer cloud pieces
means simpler setup, lower cost and easier explanation. Lambda would be the next step for a fully cloud-hosted design.

**23. What happens if the backend is down when the button is pressed?** No result arrives, so after 15 seconds the
ESP32 times out and shows the red LED.

**24. How would you scale it?** Monitor many targets, run checks from a cloud worker, store data in a managed
database, add authentication and notifications through SNS.

**25. What are the limitations?** Single target, ICMP only, local backend must be running, simulated hybrid link by
default, no user login.
