# NetPulse - System design

## 1. System architecture
```mermaid
flowchart LR
  subgraph ONPREM[On-premises site]
    UI[React dashboard]
    API[FastAPI backend<br/>ping + SQLite + MQTT client]
    ESP[ESP32 + button + LEDs]
  end
  subgraph AWS[AWS cloud]
    IOT[AWS IoT Core<br/>MQTT broker]
    EC2[EC2 in VPC<br/>ping target]
  end
  UI <-- REST + WebSocket --> API
  API -- ICMP ping --> EC2
  ESP <-- MQTT over TLS --> IOT
  API <-- MQTT over TLS --> IOT
```

## 2. Data flow (hardware trigger)
```mermaid
sequenceDiagram
  participant B as Button/ESP32
  participant I as AWS IoT Core
  participant K as FastAPI backend
  participant T as EC2 target
  participant D as Dashboard
  B->>I: publish netpulse/esp32-01/test/request
  I->>K: deliver request (subscribed)
  K->>T: ping x3
  T-->>K: replies (or none)
  K->>K: save to SQLite, raise alert if status changed
  K->>I: publish netpulse/esp32-01/test/result
  I->>B: result -> green or red LED
  K-->>D: WebSocket "test_result" -> UI updates
```
Dashboard-triggered flow: Dashboard -> `POST /api/test` -> ping -> save -> response + WebSocket broadcast.

## 3. Hardware circuit
Components: ESP32 dev board, push button, green LED, red LED, 2 x 220 ohm resistors, breadboard, jumper wires.

| Part | ESP32 pin | Other end |
|---|---|---|
| Push button | GPIO 4 | GND (internal pull-up, pressed = LOW) |
| Green LED anode (+, long leg) | GPIO 26 via 220 ohm | cathode (short leg) to GND |
| Red LED anode (+, long leg) | GPIO 27 via 220 ohm | cathode (short leg) to GND |

```
 ESP32                                   
  GPIO4  ------------ [ BUTTON ] ------- GND
  GPIO26 --[220R]--->|-- (green LED) --- GND
  GPIO27 --[220R]--->|-- (red LED)   --- GND
```
Always use the resistors: they protect the LED and the ESP32 pin.

## 4. Database design (SQLite)
```mermaid
erDiagram
  TESTS { int id PK
    text ts
    text source_network
    text destination_network
    text target
    text source
    int reachable
    real response_ms
    real packet_loss
    text error
    text mode }
  ALERTS { int id PK
    text ts
    text level
    text title
    text message }
  SETTINGS { text key PK
    text value }
```
- `tests.source` = `dashboard`, `auto` or `esp32:<device>`; `tests.mode` is always `real`.
- `alerts.level` = `critical` (lost), `success` (restored), `warning` (high latency).
- `settings` stores target, interval, timeout, latency limit, network names, link type.

## 5. REST API
| Method | Path | Purpose |
|---|---|---|
| GET | /api/health | backend + MQTT status |
| POST | /api/test | run a real ping now |
| GET | /api/stats | totals, availability, health, charts data |
| GET | /api/history | test history |
| GET | /api/alerts | alert history |
| GET/PUT | /api/settings | read / update settings (validated) |
| POST | /api/reset | clear history and alerts |
| WS | /ws | live `test_result` events |

## 6. Health score
`health = 0.7 x availability(last 50 tests) + 0.3 x speed score`, where `speed score = max(0, 100 - average_ms / 3)`.
90+ Excellent, 70+ Good, 40+ Degraded, below 40 Critical.

## 7. Security measures
Input validation (IP/hostname only), `subprocess` with an argument list and no shell, CORS limited to the dev
origin, TLS 1.2+ mutual authentication for MQTT, least-privilege IoT policies, secrets in git-ignored files only.
