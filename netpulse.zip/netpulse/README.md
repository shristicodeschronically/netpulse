# NETPULSE - Hybrid Cloud Connectivity Monitoring System

Checks whether an on-premises network can reach a cloud (AWS VPC) network using **real ping tests**,
shows the result on a live dashboard, and can be triggered from a physical ESP32 button through AWS IoT Core.

```
netpulse/
├── frontend/          React dashboard (Vite, Recharts, Lucide)
├── backend/           FastAPI: real ping, SQLite history, alerts, WebSocket, AWS IoT bridge
├── esp32-firmware/    Arduino sketch (button + 2 LEDs + MQTT)
├── aws/               AWS setup guide + IoT policies (no secrets)
├── certs/             your AWS certificates (git-ignored)
└── docs/              design, report content, testing, viva Q&A
```

## Requirements
Python 3.10+, Node.js 18+ (LTS), VS Code. For hardware: Arduino IDE. For AWS: an AWS account.

## Run it (phases 1-5 need no AWS and no hardware)

**Terminal 1 - backend**
```
cd backend
python -m venv .venv
.venv\Scripts\activate          (Windows)      source .venv/bin/activate     (macOS/Linux)
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Expected: `Uvicorn running on http://127.0.0.1:8000`. Open http://127.0.0.1:8000/docs to see the API.

**Terminal 2 - frontend**
```
cd frontend
npm install
npm run dev
```
Expected: `Local: http://localhost:5173/`. Open it in your browser.

## First test
1. Settings > Target = `8.8.8.8` (or your EC2 IP) > Save changes.
2. Live monitor > **Test connection**. Green + a real millisecond value means the ping worked.
3. Set Target to `203.0.113.1` (a documentation address that never answers) and test again: red, alert appears.
4. Check Overview, Analytics, History (Export CSV) and Alerts.

## Real vs simulated
Every result comes from the operating system's `ping`. There is no random data anywhere.
The only "simulated" part is the hybrid link (laptop to EC2 over the internet instead of a paid VPN);
the dashboard labels it, and you can choose the link type in Settings.

## Then
- Hardware: `docs/01_design.md` (wiring) and `esp32-firmware/`.
- AWS: `aws/SETUP.md`.
- Report, viva and testing material: `docs/`.

## Common problems
| Problem | Fix |
|---|---|
| Red banner "Cannot reach the backend" | Start the backend (Terminal 1) |
| `ModuleNotFoundError` | Activate the virtual environment, then `pip install -r requirements.txt` |
| `npm` not found | Install Node.js LTS from nodejs.org, reopen the terminal |
| Every test fails with "ping command is not available" | Install `ping` (Linux: `sudo apt install iputils-ping`) |
| EC2 test fails but others work | Check ICMP rule + that the public IP has not changed |
