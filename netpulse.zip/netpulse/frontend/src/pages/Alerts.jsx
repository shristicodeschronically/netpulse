import { AlertOctagon, CheckCircle2, AlertTriangle } from "lucide-react";
import { Empty, timeAgo, fmtDateTime } from "../components/ui.jsx";

const ICON = { critical: AlertOctagon, success: CheckCircle2, warning: AlertTriangle };
const TONE = { critical: "bad", success: "ok", warning: "warn" };

export default function Alerts({ data }) {
  return (
    <section className="card">
      <h2>Recent alerts</h2>
      {data.alerts.length === 0 ? (
        <Empty title="No alerts" text="You will see an alert when the connection drops, comes back, or gets slow." />
      ) : (
        <ul className="alerts">
          {data.alerts.map((a) => {
            const Icon = ICON[a.level] || AlertTriangle;
            return (
              <li key={a.id} className={TONE[a.level]}>
                <Icon size={22} />
                <div className="grow"><strong>{a.title}</strong><p>{a.message}</p></div>
                <span className="muted" title={fmtDateTime(a.ts)}>{timeAgo(a.ts)}</span>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
