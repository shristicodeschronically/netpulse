import { useState } from "react";
import { Save, Trash2 } from "lucide-react";
import { api } from "../api.js";

export default function Settings({ data, refresh }) {
  const [f, setF] = useState(data.settings);
  const [msg, setMsg] = useState(null);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });

  async function save(e) {
    e.preventDefault();
    try {
      await api.saveSettings({
        ...f,
        interval_seconds: Number(f.interval_seconds),
        timeout_ms: Number(f.timeout_ms),
        alert_latency_ms: Number(f.alert_latency_ms),
      });
      await refresh();
      setMsg({ ok: true, text: "Settings saved" });
    } catch (err) {
      setMsg({ ok: false, text: err.message });
    }
  }

  async function reset() {
    if (window.confirm("Delete all test history and alerts? This cannot be undone.")) {
      await api.reset();
      await refresh();
      setMsg({ ok: true, text: "History cleared" });
    }
  }

  return (
    <form className="card settings" onSubmit={save}>
      <h2>Connection target</h2>
      <label>Target IP address or hostname
        <input value={f.target} onChange={set("target")} placeholder="e.g. 13.233.10.5" />
        <small>Use the public IP of your EC2 instance to test the AWS side.</small>
      </label>
      <div className="grid cols-2">
        <label>Source network name<input value={f.source_name} onChange={set("source_name")} /></label>
        <label>Destination network name<input value={f.dest_name} onChange={set("dest_name")} /></label>
      </div>
      <label>Type of link between the networks
        <select value={f.link_mode} onChange={set("link_mode")}>
          <option value="simulated">Simulated hybrid link (internet ping)</option>
          <option value="wireguard">WireGuard tunnel</option>
          <option value="vpn">AWS Site-to-Site VPN</option>
        </select>
      </label>

      <h2>Monitoring</h2>
      <label className="check"><input type="checkbox" checked={f.auto_monitor} onChange={set("auto_monitor")} /> Test automatically in the background</label>
      <div className="grid cols-3">
        <label>Test interval (seconds)<input type="number" value={f.interval_seconds} onChange={set("interval_seconds")} /></label>
        <label>Ping timeout (ms)<input type="number" value={f.timeout_ms} onChange={set("timeout_ms")} /></label>
        <label>High-latency alert above (ms)<input type="number" value={f.alert_latency_ms} onChange={set("alert_latency_ms")} /></label>
      </div>

      <div className="row">
        <button className="btn primary" type="submit"><Save size={16} /> Save changes</button>
        <button className="btn danger" type="button" onClick={reset}><Trash2 size={16} /> Clear history</button>
        {msg && <span className={msg.ok ? "ok-text" : "bad-text"} role="status">{msg.text}</span>}
      </div>
    </form>
  );
}
