import { Activity, CheckCircle2, XCircle, Timer, Radio, ShieldCheck } from "lucide-react";
import { StatCard, HealthRing, healthLabel, Badge, Empty, sourceLabel, timeAgo } from "../components/ui.jsx";

export default function Overview({ data, go }) {
  const s = data.stats.summary;
  const status = {
    connected: ["CONNECTED", "ok"],
    disconnected: ["DISCONNECTED", "bad"],
    unknown: ["NO TESTS YET", ""],
  }[s.current];

  return (
    <>
      <div className="grid cols-3">
        <StatCard icon={Activity} label="Total connection tests" value={s.total} />
        <StatCard icon={CheckCircle2} label="Successful connections" value={s.success} tone="ok" />
        <StatCard icon={XCircle} label="Failed connections" value={s.failed} tone={s.failed ? "bad" : ""} />
        <StatCard icon={Radio} label="Current network status" value={status[0]} tone={status[1]}
          note={s.last ? `Last test ${timeAgo(s.last.ts)} to ${s.last.target}` : "Run a test from Live monitor"} />
        <StatCard icon={Timer} label="Average response time" value={s.avg_ms ?? "-"} unit={s.avg_ms != null ? "ms" : ""}
          note="Successful tests only" />
        <div className="card stat health">
          <div className="stat-head"><span>Network health score</span><ShieldCheck size={18} /></div>
          {s.health == null ? <div className="stat-value">-</div> : (
            <div className="health-body">
              <HealthRing value={s.health} />
              <div>
                <div className="stat-value small">{healthLabel(s.health)}</div>
                <div className="stat-note">70% availability + 30% speed, last 50 tests</div>
              </div>
            </div>
          )}
        </div>
      </div>

      <section className="card">
        <h2>Latest tests</h2>
        {data.history.length === 0 ? (
          <Empty title="No tests yet" text="Run your first real ping test to see results here.">
            <button className="btn primary" onClick={() => go("live")}>Open live monitor</button>
          </Empty>
        ) : (
          <ul className="feed">
            {data.history.slice(0, 6).map((t) => (
              <li key={t.id}>
                <Badge tone={t.reachable ? "ok" : "bad"}>{t.reachable ? "Success" : "Failed"}</Badge>
                <span className="grow">{t.source_network} to {t.destination_network} ({t.target})</span>
                <span className="muted">{sourceLabel(t.source)}</span>
                <b>{t.reachable ? `${t.response_ms} ms` : "no reply"}</b>
                <span className="muted">{timeAgo(t.ts)}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}
