import { useState } from "react";
import { Download } from "lucide-react";
import { Badge, Empty, fmtDateTime, sourceLabel } from "../components/ui.jsx";

function exportCsv(rows) {
  const head = ["time", "source_network", "destination_network", "target", "triggered_by", "success", "response_ms", "packet_loss", "note"];
  const lines = rows.map((t) => [t.ts, t.source_network, t.destination_network, t.target, sourceLabel(t.source), t.reachable, t.response_ms ?? "", t.packet_loss, t.error ?? ""]
    .map((v) => `"${String(v).replaceAll('"', '""')}"`).join(","));
  const url = URL.createObjectURL(new Blob([[head.join(","), ...lines].join("\n")], { type: "text/csv" }));
  const a = Object.assign(document.createElement("a"), { href: url, download: "netpulse-history.csv" });
  a.click();
  URL.revokeObjectURL(url);
}

export default function History({ data }) {
  const [filter, setFilter] = useState("all");
  const rows = data.history.filter((t) => filter === "all" || (filter === "ok") === t.reachable);

  return (
    <section className="card">
      <div className="row between">
        <div className="tabs">
          {[["all", "All"], ["ok", "Successful"], ["bad", "Failed"]].map(([k, l]) => (
            <button key={k} className={filter === k ? "active" : ""} onClick={() => setFilter(k)}>{l}</button>
          ))}
        </div>
        <button className="btn" onClick={() => exportCsv(rows)} disabled={!rows.length}><Download size={16} /> Export CSV</button>
      </div>
      {rows.length === 0 ? <Empty title="No matching tests" text="Tests you run appear here with their real results." /> : (
        <div className="table-wrap">
          <table>
            <thead><tr><th>Date and time</th><th>Source</th><th>Destination</th><th>Result</th><th>Response</th><th>Status</th><th>Triggered by</th></tr></thead>
            <tbody>
              {rows.map((t) => (
                <tr key={t.id}>
                  <td>{fmtDateTime(t.ts)}</td>
                  <td>{t.source_network}</td>
                  <td>{t.destination_network}<div className="muted">{t.target}</div></td>
                  <td>{t.reachable ? `Reply received (${t.packet_loss}% loss)` : t.error}</td>
                  <td>{t.reachable ? `${t.response_ms} ms` : "-"}</td>
                  <td><Badge tone={t.reachable ? "ok" : "bad"}>{t.reachable ? "Success" : "Failed"}</Badge></td>
                  <td>{sourceLabel(t.source)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
