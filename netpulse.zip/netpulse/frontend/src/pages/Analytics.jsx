import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell, BarChart, Bar, Legend } from "recharts";
import { Empty } from "../components/ui.jsx";

const C = { ok: "#2ee6a6", bad: "#ff5c7a", accent: "#4d8dff", grid: "#1f3159", text: "#8396bd" };
const tip = { contentStyle: { background: "#0f1b36", border: "1px solid #1f3159", borderRadius: 8, color: "#e7eefc" } };

export default function Analytics({ data }) {
  const { summary, series, daily } = data.stats;
  if (!summary.total) return <section className="card"><Empty title="Nothing to chart yet" text="Run a few tests and the charts fill in." /></section>;

  const pie = [{ name: "Successful", value: summary.success }, { name: "Failed", value: summary.failed }];
  const line = series.map((p) => ({ time: new Date(p.ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }), ms: p.response_ms }));
  const axis = { stroke: C.text, fontSize: 12, tickLine: false, axisLine: false };

  return (
    <div className="grid cols-2">
      <section className="card avail">
        <h2>Network availability</h2>
        <div className="big-number">{summary.availability}<small>%</small></div>
        <div className="bar"><i style={{ width: `${summary.availability}%` }} /></div>
        <p className="muted">{summary.success} of {summary.total} tests reached the target.</p>
      </section>

      <section className="card">
        <h2>Successful vs failed</h2>
        <ResponsiveContainer width="100%" height={200}>
          <PieChart>
            <Pie data={pie} dataKey="value" innerRadius={55} outerRadius={80} stroke="none" paddingAngle={2}>
              <Cell fill={C.ok} /><Cell fill={C.bad} />
            </Pie>
            <Tooltip {...tip} /><Legend />
          </PieChart>
        </ResponsiveContainer>
      </section>

      <section className="card span2">
        <h2>Response time history (last {series.length} tests)</h2>
        <ResponsiveContainer width="100%" height={260}>
          <AreaChart data={line}>
            <defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={C.accent} stopOpacity={0.45} /><stop offset="100%" stopColor={C.accent} stopOpacity={0} />
            </linearGradient></defs>
            <CartesianGrid stroke={C.grid} vertical={false} />
            <XAxis dataKey="time" {...axis} /><YAxis unit=" ms" {...axis} width={60} />
            <Tooltip {...tip} formatter={(v) => (v == null ? "no reply" : `${v} ms`)} />
            <Area type="monotone" dataKey="ms" stroke={C.accent} strokeWidth={2} fill="url(#g)" connectNulls={false} />
          </AreaChart>
        </ResponsiveContainer>
      </section>

      <section className="card span2">
        <h2>Daily connection statistics (last 7 days)</h2>
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={daily}>
            <CartesianGrid stroke={C.grid} vertical={false} />
            <XAxis dataKey="date" {...axis} /><YAxis allowDecimals={false} {...axis} width={40} />
            <Tooltip {...tip} cursor={{ fill: "rgba(77,141,255,.08)" }} /><Legend />
            <Bar dataKey="success" name="Successful" stackId="a" fill={C.ok} />
            <Bar dataKey="failed" name="Failed" stackId="a" fill={C.bad} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </section>
    </div>
  );
}
