import { Server, Cloud, Zap, Loader2 } from "lucide-react";
import { Badge, LINK_LABELS, sourceLabel, fmtDateTime } from "../components/ui.jsx";

const PULSE = "M0 40 H150 l12 -26 l16 52 l14 -42 l10 16 H400";
const FLAT = "M0 40 H165 M235 40 H400";

export default function Live({ data, testing, onTest }) {
  const { settings } = data;
  const last = data.stats.summary.last;
  const state = testing ? "testing" : !last ? "idle" : last.reachable ? "up" : "down";
  const label = { testing: "TESTING...", idle: "NOT TESTED", up: "CONNECTED", down: "DISCONNECTED" }[state];

  return (
    <section className="card live">
      <div className="live-top">
        <Badge tone="warn">{LINK_LABELS[settings.link_mode]}</Badge>
        <Badge tone="info">Real ping results</Badge>
      </div>

      <div className="link">
        <div className={`node ${state}`}>
          <Server size={30} />
          <strong>{settings.source_name}</strong>
          <span className="muted">On-premises</span>
        </div>

        <svg className={`wire ${state}`} viewBox="0 0 400 80" preserveAspectRatio="none" aria-hidden="true">
          <path d={state === "down" ? FLAT : PULSE} />
          {state === "down" && <text x="200" y="46" textAnchor="middle">x</text>}
        </svg>

        <div className={`node ${state}`}>
          <Cloud size={30} />
          <strong>{settings.dest_name}</strong>
          <span className="muted">{settings.target}</span>
        </div>
      </div>

      <div className={`verdict ${state}`}>
        <div className="verdict-word">{label}</div>
        <div className="verdict-ms">
          {state === "up" && <>{last.response_ms}<small>ms</small></>}
          {state === "down" && <span className="reason">{last.error}</span>}
          {state === "idle" && <span className="reason">Press the button to send a real ping to {settings.target}</span>}
        </div>
      </div>

      <button className="btn primary big" onClick={onTest} disabled={testing}>
        {testing ? <Loader2 size={18} className="spin" /> : <Zap size={18} />}
        {testing ? "Testing connection" : "Test connection"}
      </button>

      {last && (
        <dl className="facts">
          <div><dt>Target</dt><dd>{last.target}</dd></div>
          <div><dt>Packet loss</dt><dd>{last.packet_loss}%</dd></div>
          <div><dt>Triggered by</dt><dd>{sourceLabel(last.source)}</dd></div>
          <div><dt>Time</dt><dd>{fmtDateTime(last.ts)}</dd></div>
        </dl>
      )}
    </section>
  );
}
