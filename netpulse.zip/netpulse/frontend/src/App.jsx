import { useCallback, useEffect, useState } from "react";
import { LayoutDashboard, Radio, BarChart3, History as HistoryIcon, Bell, Settings as SettingsIcon, WifiOff, Activity } from "lucide-react";
import { api } from "./api.js";
import Overview from "./pages/Overview.jsx";
import Live from "./pages/Live.jsx";
import Analytics from "./pages/Analytics.jsx";
import History from "./pages/History.jsx";
import Alerts from "./pages/Alerts.jsx";
import Settings from "./pages/Settings.jsx";
import { LINK_LABELS, sourceLabel } from "./components/ui.jsx";

const PAGES = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "live", label: "Live monitor", icon: Radio },
  { id: "analytics", label: "Analytics", icon: BarChart3 },
  { id: "history", label: "History", icon: HistoryIcon },
  { id: "alerts", label: "Alerts", icon: Bell },
  { id: "settings", label: "Settings", icon: SettingsIcon },
];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export default function App() {
  const [page, setPage] = useState(location.hash.slice(1) || "overview");
  const [data, setData] = useState(null);
  const [offline, setOffline] = useState(false);
  const [live, setLive] = useState(false);
  const [testing, setTesting] = useState(false);
  const [toast, setToast] = useState(null);
  const [seen, setSeen] = useState(() => Number(localStorage.getItem("np_seen") || 0));

  const go = (id) => { setPage(id); location.hash = id; };

  const refresh = useCallback(async () => {
    try {
      const [stats, history, alerts, settings] = await Promise.all([api.stats(), api.history(), api.alerts(), api.settings()]);
      setData({ stats, history, alerts, settings });
      setOffline(false);
    } catch {
      setOffline(true);
    }
  }, []);

  useEffect(() => { refresh(); const t = setInterval(refresh, 15000); return () => clearInterval(t); }, [refresh]);

  useEffect(() => {
    let ws, retry, closed = false;
    const connect = () => {
      ws = new WebSocket(`${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/ws`);
      ws.onopen = () => setLive(true);
      ws.onclose = () => { setLive(false); if (!closed) retry = setTimeout(connect, 3000); };
      ws.onmessage = (e) => {
        const m = JSON.parse(e.data);
        if (m.type === "test_result") {
          refresh();
          const t = m.data;
          setToast({ ok: t.reachable, text: `${sourceLabel(t.source)}: ${t.reachable ? `connected, ${t.response_ms} ms` : "disconnected"}` });
          setTimeout(() => setToast(null), 4500);
        } else if (m.type === "reset") refresh();
      };
    };
    connect();
    return () => { closed = true; clearTimeout(retry); ws && ws.close(); };
  }, [refresh]);

  useEffect(() => {
    if (page === "alerts" && data?.alerts.length) {
      const top = data.alerts[0].id;
      localStorage.setItem("np_seen", top);
      setSeen(top);
    }
  }, [page, data]);

  async function runTest() {
    setTesting(true);
    try { await Promise.all([api.runTest(), sleep(1000)]); } catch { setOffline(true); }
    await refresh();
    setTesting(false);
  }

  const unseen = data ? data.alerts.filter((a) => a.id > seen).length : 0;
  const current = PAGES.find((p) => p.id === page) || PAGES[0];

  return (
    <div className="app">
      <nav className="side" aria-label="Main">
        <div className="brand"><Activity size={22} /><span>NETPULSE</span></div>
        {PAGES.map(({ id, label, icon: Icon }) => (
          <button key={id} className={page === id ? "active" : ""} onClick={() => go(id)}>
            <Icon size={18} /><span>{label}</span>
            {id === "alerts" && unseen > 0 && <em>{unseen}</em>}
          </button>
        ))}
        {data && <div className="side-foot">{LINK_LABELS[data.settings.link_mode]}</div>}
      </nav>

      <main>
        <header className="top">
          <h1>{current.label}</h1>
          <div className="row">
            <span className={`pill ${live ? "ok" : ""}`}><i />{live ? "Live updates" : "Polling"}</span>
            <button className="btn primary" onClick={runTest} disabled={testing || !data}>Test now</button>
          </div>
        </header>

        {offline && (
          <div className="banner" role="alert">
            <WifiOff size={18} />
            <div><strong>Cannot reach the NetPulse backend.</strong> Start it: open a terminal in <code>backend</code> and run <code>uvicorn app.main:app --reload</code></div>
          </div>
        )}

        {!data ? <p className="muted">Loading...</p> : (
          <>
            {page === "overview" && <Overview data={data} go={go} />}
            {page === "live" && <Live data={data} testing={testing} onTest={runTest} />}
            {page === "analytics" && <Analytics data={data} />}
            {page === "history" && <History data={data} />}
            {page === "alerts" && <Alerts data={data} />}
            {page === "settings" && <Settings key={JSON.stringify(data.settings)} data={data} refresh={refresh} />}
          </>
        )}
      </main>

      {toast && <div className={`toast ${toast.ok ? "ok" : "bad"}`} role="status">{toast.text}</div>}
    </div>
  );
}
