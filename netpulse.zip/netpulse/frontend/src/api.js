// All calls to the FastAPI backend live here.
async function request(path, options) {
  const res = await fetch(path, { headers: { "Content-Type": "application/json" }, ...options });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(typeof body.detail === "string" ? body.detail : "Request failed");
  }
  return res.json();
}

export const api = {
  health: () => request("/api/health"),
  stats: () => request("/api/stats"),
  history: () => request("/api/history?limit=300"),
  alerts: () => request("/api/alerts?limit=100"),
  settings: () => request("/api/settings"),
  saveSettings: (values) => request("/api/settings", { method: "PUT", body: JSON.stringify(values) }),
  runTest: () => request("/api/test", { method: "POST" }),
  reset: () => request("/api/reset", { method: "POST" }),
};
