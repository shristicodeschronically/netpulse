import { Inbox } from "lucide-react";

export const fmtDateTime = (iso) =>
  new Date(iso).toLocaleString([], { dateStyle: "medium", timeStyle: "medium" });

export function timeAgo(iso) {
  const s = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  return `${Math.floor(s / 86400)} d ago`;
}

export function sourceLabel(src = "") {
  if (src === "dashboard") return "Dashboard button";
  if (src === "auto") return "Auto monitor";
  if (src.startsWith("esp32")) return `ESP32 button (${src.split(":")[1] || "device"})`;
  return src;
}

export const LINK_LABELS = {
  simulated: "Simulated hybrid link",
  wireguard: "WireGuard tunnel",
  vpn: "AWS Site-to-Site VPN",
};

export function StatCard({ icon: Icon, label, value, unit, tone = "", note }) {
  return (
    <div className={`card stat ${tone}`}>
      <div className="stat-head">
        <span>{label}</span>
        <Icon size={18} />
      </div>
      <div className="stat-value">
        {value}
        {unit && <small>{unit}</small>}
      </div>
      {note && <div className="stat-note">{note}</div>}
    </div>
  );
}

export function Badge({ tone = "muted", children }) {
  return <span className={`badge ${tone}`}>{children}</span>;
}

export function Empty({ title, text, children }) {
  return (
    <div className="empty">
      <Inbox size={28} />
      <strong>{title}</strong>
      <p>{text}</p>
      {children}
    </div>
  );
}

export function HealthRing({ value }) {
  const r = 34, c = 2 * Math.PI * r;
  const tone = value >= 90 ? "ok" : value >= 70 ? "ok" : value >= 40 ? "warn" : "bad";
  return (
    <svg viewBox="0 0 84 84" className={`ring ${tone}`} aria-label={`Health score ${value}`}>
      <circle cx="42" cy="42" r={r} className="ring-bg" />
      <circle cx="42" cy="42" r={r} className="ring-fg" strokeDasharray={`${(c * value) / 100} ${c}`}
        transform="rotate(-90 42 42)" />
      <text x="42" y="47" textAnchor="middle">{value}</text>
    </svg>
  );
}

export const healthLabel = (v) => (v >= 90 ? "Excellent" : v >= 70 ? "Good" : v >= 40 ? "Degraded" : "Critical");
