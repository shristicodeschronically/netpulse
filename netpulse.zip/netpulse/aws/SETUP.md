# AWS setup guide (Phase 7)

Nothing here exists yet in your account. Follow the steps in order. Use one region for everything
(for Chennai, **Asia Pacific (Mumbai) ap-south-1** is the closest).
Check the AWS Free Tier page for current limits, and **stop or terminate resources after your demo**.

## Part A - the cloud side: VPC + EC2 (the thing we ping)

1. Console > **VPC** > *Create VPC* > choose **VPC and more**. Name `netpulse`, 1 public subnet,
   0 private subnets, NAT gateways **None** (NAT gateways cost money).
2. Console > **EC2** > *Launch instance*. Name `netpulse-target`, Amazon Linux 2023,
   instance type `t3.micro` or `t2.micro` (whichever is marked free-tier eligible), network = the `netpulse` VPC,
   public subnet, **Auto-assign public IP: Enable**. No key pair is needed (we never log in).
3. Security group: add one inbound rule: **Type = All ICMP - IPv4**, Source = **My IP**.
   (ICMP is what `ping` uses. Do not open it to 0.0.0.0/0.)
4. Copy the instance's **Public IPv4 address**. Put it in NetPulse > Settings > Target.
   Note: the address changes if you stop and start the instance.

Test from your laptop terminal: `ping <that IP>` should reply.

### How "hybrid" is shown
| Mode | What it is | In NetPulse Settings |
|---|---|---|
| Simulated hybrid link | Your laptop (on-premises) pings the EC2 in the VPC over the internet. | *Simulated hybrid link* |
| WireGuard tunnel (optional) | Install WireGuard on EC2 and laptop, ping EC2's tunnel IP (e.g. 10.8.0.1). A real encrypted tunnel, free. | *WireGuard tunnel* |
| AWS Site-to-Site VPN (concept) | Virtual Private Gateway on the VPC + Customer Gateway (your router's public IP) + VPN connection, routes propagated. Real, billed per hour, needs a router that supports IPsec. Describe it in the report; do not build it for the demo. | *AWS Site-to-Site VPN* |

The dashboard always shows which mode you picked, so a simulated link is never presented as a real VPN.

## Part B - AWS IoT Core

### B1. Find your endpoint
IoT Core > **Settings** > *Device data endpoint*. Copy it (looks like `xxxx-ats.iot.ap-south-1.amazonaws.com`).

### B2. Create the ESP32 "thing"
1. IoT Core > **All devices > Things > Create things > Create single thing**. Name: **`esp32-01`** (exactly).
2. *Auto-generate a new certificate*.
3. *Create policy*: name `NetPulseEsp32Policy`, JSON tab, paste `aws/esp32-device-policy.json`.
   Replace `REGION` (e.g. `ap-south-1`) and `ACCOUNT_ID` (your 12-digit id, top-right menu).
4. Attach the policy and create the thing. **Download now** (the private key is shown only once):
   device certificate, private key, and **Amazon Root CA 1**.
   Rename to `esp32.cert.pem`, `esp32.private.key`, `AmazonRootCA1.pem` and keep them in `certs/`.

### B3. Create the backend "thing"
Repeat B2 with thing name **`netpulse-backend`**, policy `NetPulseBackendPolicy` from
`aws/backend-policy.json`. Save the files as `backend.cert.pem` and `backend.private.key`.

### B4. Connect the backend
```
cd backend
copy .env.example .env      (Windows)     cp .env.example .env      (macOS/Linux)
```
Edit `.env`: set `AWS_IOT_ENDPOINT`. Restart uvicorn. Open http://127.0.0.1:8000/api/health and look for
`"mqtt": {"status": "connected"}`.

### B5. Test without hardware
IoT Core > **MQTT test client**. Subscribe to `netpulse/esp32-01/test/result`, then publish to
`netpulse/esp32-01/test/request` the message `{"request_id":"1","device":"esp32-01"}`.
You should receive a result with `"connected":true` (or `false`), and a new "ESP32 button" row appears
in the dashboard history. (Or use `backend/scripts/fake_esp32.py`.)

### B6. Flash the ESP32
Copy `esp32-firmware/netpulse_esp32/secrets.example.h` to `secrets.h`, fill in Wi-Fi, endpoint and paste the three
certificate files. Upload, open Serial Monitor at 115200 baud, press the button.

## MQTT topics
| Topic | Published by | Subscribed by | Payload |
|---|---|---|---|
| `netpulse/esp32-01/test/request` | ESP32 | Backend (`netpulse/+/test/request`) | `{"request_id","device"}` |
| `netpulse/esp32-01/test/result` | Backend | ESP32 | `{"request_id","device","connected","response_ms","target","ts"}` |

## Security checklist
- Certificates, private keys, `.env` and `secrets.h` are git-ignored. Never paste them into the frontend or a chat.
- Each device has its own certificate and a least-privilege policy (only its own topics).
- If a key leaks: IoT Core > Certificates > *Deactivate*, then create a new one.
- Traffic uses TLS on port 8883 with mutual authentication (device certificate + AWS root CA).
- No AWS access keys are used anywhere in this project.

## Troubleshooting
| Symptom | Likely cause |
|---|---|
| ESP32 prints `failed (state 5)` | Policy missing/not attached, or client id is not `esp32-01` |
| ESP32 prints `state -2` | Wrong endpoint, Wi-Fi blocks port 8883, or clock not synced |
| `/api/health` shows `error: Certificate file not found` | Wrong path in `.env` (paths are relative to `backend/`) |
| Backend `connected`, ESP32 gets no result | Backend policy lacks Subscribe/Receive for `netpulse/+/test/request` |
| Ping to EC2 times out | ICMP rule missing, wrong IP (it changed), or source IP changed |
