Put your AWS IoT certificates here (device + backend). This folder is git-ignored. NEVER commit or share these files.
