"""Pretend to be the ESP32 (for testing AWS IoT without hardware).
Use ONLY while the real ESP32 is switched off (same client id / certificate).

  python scripts/fake_esp32.py --endpoint xxxx-ats.iot.ap-south-1.amazonaws.com \
      --cert ../certs/esp32.cert.pem --key ../certs/esp32.private.key --ca ../certs/AmazonRootCA1.pem
"""
import argparse, json, ssl, time
import paho.mqtt.client as mqtt

p = argparse.ArgumentParser()
p.add_argument("--endpoint", required=True)
p.add_argument("--cert", required=True)
p.add_argument("--key", required=True)
p.add_argument("--ca", required=True)
p.add_argument("--device", default="esp32-01")
a = p.parse_args()
req_id = str(int(time.time()))
done = False


def on_connect(c, u, f, rc, props):
    print("connected:", rc)
    c.subscribe(f"netpulse/{a.device}/test/result", qos=1)
    c.publish(f"netpulse/{a.device}/test/request", json.dumps({"request_id": req_id, "device": a.device}), qos=1)
    print("button pressed (request sent)")


def on_message(c, u, m):
    global done
    data = json.loads(m.payload)
    print("result:", data)
    print("GREEN LED ON" if data["connected"] else "RED LED ON")
    done = True


c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=a.device)
c.tls_set(ca_certs=a.ca, certfile=a.cert, keyfile=a.key, tls_version=ssl.PROTOCOL_TLS_CLIENT)
c.on_connect, c.on_message = on_connect, on_message
c.connect(a.endpoint, 8883, 60)
c.loop_start()
for _ in range(20):
    if done:
        break
    time.sleep(1)
if not done:
    print("No reply in 20 s - is the backend running and connected to AWS IoT?")
c.loop_stop()
