"""SQLite storage: tests, alerts and settings."""
import json
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "netpulse.db"
_lock = threading.Lock()

DEFAULTS = {
    "target": "8.8.8.8",
    "interval_seconds": 30,
    "auto_monitor": False,
    "timeout_ms": 2000,
    "alert_latency_ms": 150,
    "source_name": "Local network",
    "dest_name": "AWS VPC",
    "link_mode": "simulated",  # simulated | wireguard | vpn
}


@contextmanager
def conn():
    with _lock:
        c = sqlite3.connect(DB_PATH)
        c.row_factory = sqlite3.Row
        try:
            yield c
            c.commit()
        finally:
            c.close()


def init_db():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS tests(
          id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL,
          source_network TEXT, destination_network TEXT, target TEXT,
          source TEXT, reachable INTEGER, response_ms REAL,
          packet_loss REAL, error TEXT, mode TEXT DEFAULT 'real');
        CREATE TABLE IF NOT EXISTS alerts(
          id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL,
          level TEXT, title TEXT, message TEXT);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
        """)


def get_settings() -> dict:
    with conn() as c:
        rows = c.execute("SELECT key, value FROM settings").fetchall()
    out = dict(DEFAULTS)
    out.update({r["key"]: json.loads(r["value"]) for r in rows})
    return out


def update_settings(values: dict):
    with conn() as c:
        for k, v in values.items():
            c.execute("INSERT INTO settings(key,value) VALUES(?,?) "
                      "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, json.dumps(v)))


def add_test(rec: dict) -> dict:
    with conn() as c:
        cur = c.execute(
            "INSERT INTO tests(ts,source_network,destination_network,target,source,reachable,"
            "response_ms,packet_loss,error,mode) VALUES(?,?,?,?,?,?,?,?,?,?)",
            (rec["ts"], rec["source_network"], rec["destination_network"], rec["target"],
             rec["source"], int(rec["reachable"]), rec["response_ms"], rec["packet_loss"],
             rec["error"], rec["mode"]))
        rec["id"] = cur.lastrowid
    return rec


def last_test():
    with conn() as c:
        r = c.execute("SELECT * FROM tests ORDER BY id DESC LIMIT 1").fetchone()
    return _test(r) if r else None


def _test(r) -> dict:
    d = dict(r)
    d["reachable"] = bool(d["reachable"])
    return d


def list_tests(limit=200):
    with conn() as c:
        rows = c.execute("SELECT * FROM tests ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [_test(r) for r in rows]


def add_alert(ts, level, title, message):
    with conn() as c:
        c.execute("INSERT INTO alerts(ts,level,title,message) VALUES(?,?,?,?)", (ts, level, title, message))


def list_alerts(limit=50):
    with conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT ?", (limit,))]


def reset_data():
    with conn() as c:
        c.execute("DELETE FROM tests")
        c.execute("DELETE FROM alerts")


def stats() -> dict:
    with conn() as c:
        row = c.execute("SELECT COUNT(*) t, SUM(reachable) s, "
                        "AVG(CASE WHEN reachable=1 THEN response_ms END) a FROM tests").fetchone()
        recent = c.execute("SELECT reachable, response_ms FROM tests ORDER BY id DESC LIMIT 50").fetchall()
        last = c.execute("SELECT * FROM tests ORDER BY id DESC LIMIT 1").fetchone()
        series = c.execute("SELECT ts, response_ms, reachable FROM tests ORDER BY id DESC LIMIT 30").fetchall()[::-1]
        daily = c.execute(
            "SELECT date(ts,'localtime') d, SUM(reachable) ok, COUNT(*)-SUM(reachable) bad FROM tests "
            "WHERE date(ts,'localtime') >= date('now','localtime','-6 days') GROUP BY d ORDER BY d").fetchall()

    total, ok = row["t"] or 0, int(row["s"] or 0)
    availability = round(100 * ok / total, 1) if total else None
    health = None
    if recent:
        ra = 100 * sum(r["reachable"] for r in recent) / len(recent)
        times = [r["response_ms"] for r in recent if r["reachable"] and r["response_ms"] is not None]
        lat_score = max(0, 100 - (sum(times) / len(times)) / 3) if times else 0
        health = round(0.7 * ra + 0.3 * lat_score)
    current = "unknown" if not last else ("connected" if last["reachable"] else "disconnected")
    return {
        "summary": {
            "total": total, "success": ok, "failed": total - ok,
            "avg_ms": round(row["a"], 1) if row["a"] is not None else None,
            "availability": availability, "health": health, "current": current,
            "last": _test(last) if last else None,
        },
        "series": [{"ts": r["ts"], "response_ms": r["response_ms"], "reachable": bool(r["reachable"])} for r in series],
        "daily": [{"date": r["d"], "success": int(r["ok"] or 0), "failed": int(r["bad"] or 0)} for r in daily],
    }
