"""Real connectivity test using the operating system's ping command.

Safety rules:
  * the target is validated (IP address or hostname only)
  * subprocess gets a LIST of arguments and never uses shell=True,
    so nothing the user types can be run as a command
"""
import ipaddress
import math
import platform
import re
import shutil
import subprocess

COUNT = 3
HOST_RE = re.compile(
    r"^(?=.{1,253}$)[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?"
    r"(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$"
)
TIME_RE = re.compile(r"time\s*[=<]\s*([\d.]+)\s*ms", re.IGNORECASE)


def validate_target(target: str) -> str:
    t = (target or "").strip()
    if not t:
        raise ValueError("Target cannot be empty")
    try:
        ipaddress.ip_address(t)
        return t
    except ValueError:
        pass
    if HOST_RE.match(t):
        return t
    raise ValueError("Enter a valid IP address (e.g. 13.233.10.5) or hostname (e.g. example.com)")


def _build_command(target: str, timeout_ms: int) -> list[str]:
    system = platform.system().lower()
    if system == "windows":
        return ["ping", "-n", str(COUNT), "-w", str(timeout_ms), target]
    if system == "darwin":  # macOS: -W is in milliseconds
        return ["ping", "-c", str(COUNT), "-W", str(timeout_ms), target]
    return ["ping", "-c", str(COUNT), "-W", str(max(1, math.ceil(timeout_ms / 1000))), target]  # Linux


def run_ping(target: str, timeout_ms: int = 2000) -> dict:
    result = {
        "target": target, "reachable": False, "response_ms": None,
        "packets_sent": COUNT, "packets_received": 0, "packet_loss": 100.0,
        "error": None, "mode": "real",
    }
    try:
        target = validate_target(target)
        result["target"] = target
    except ValueError as exc:
        result["error"] = str(exc)
        return result

    if shutil.which("ping") is None:
        result["error"] = "The 'ping' command is not available on this computer"
        return result

    try:
        proc = subprocess.run(
            _build_command(target, timeout_ms),
            capture_output=True, text=True, errors="replace",
            timeout=COUNT * (timeout_ms / 1000) + 3,
        )
    except subprocess.TimeoutExpired:
        result["error"] = "Test timed out"
        return result
    except OSError as exc:
        result["error"] = f"Could not run ping: {exc}"
        return result

    times = [float(m) for m in TIME_RE.findall(proc.stdout)]
    result["packets_received"] = len(times)
    result["packet_loss"] = round(100 * (COUNT - len(times)) / COUNT, 1)
    if times:
        result["reachable"] = True
        result["response_ms"] = round(sum(times) / len(times), 1)
    else:
        result["error"] = "No reply (host unreachable or timed out)"
    return result
