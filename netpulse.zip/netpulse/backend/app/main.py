"""NetPulse backend (FastAPI).  Run:  uvicorn app.main:app --reload"""
import asyncio
import platform
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

load_dotenv()

from . import database as db  # noqa: E402
from .mqtt_client import bridge  # noqa: E402
from .ping_service import run_ping, validate_target  # noqa: E402


class Manager:
    """Keeps the open dashboard WebSocket connections."""

    def __init__(self):
        self.clients, self.loop = set(), None

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.clients.add(ws)

    async def broadcast(self, msg: dict):
        for ws in list(self.clients):
            try:
                await ws.send_json(msg)
            except Exception:
                self.clients.discard(ws)

    def push(self, msg: dict):  # safe to call from any thread
        if self.loop:
            asyncio.run_coroutine_threadsafe(self.broadcast(msg), self.loop)


manager = Manager()


def execute_test(source: str) -> dict:
    """Run one REAL ping, save it, raise alerts on status changes, notify dashboards."""
    s = db.get_settings()
    res = run_ping(s["target"], s["timeout_ms"])
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    rec = {
        "ts": now, "source_network": s["source_name"], "destination_network": s["dest_name"],
        "target": res["target"], "source": source, "reachable": res["reachable"],
        "response_ms": res["response_ms"], "packet_loss": res["packet_loss"],
        "error": res["error"], "mode": res["mode"],
    }
    prev = db.last_test()
    db.add_test(rec)

    if not rec["reachable"] and (prev is None or prev["reachable"]):
        db.add_alert(now, "critical", "Connection lost",
                     f"{s['source_name']} cannot reach {s['dest_name']} ({rec['target']}). {rec['error'] or ''}".strip())
    elif rec["reachable"] and prev and not prev["reachable"]:
        db.add_alert(now, "success", "Connection restored",
                     f"{s['dest_name']} ({rec['target']}) is reachable again at {rec['response_ms']} ms.")
    elif rec["reachable"] and rec["response_ms"] > s["alert_latency_ms"] and not (
            prev and prev["reachable"] and prev["response_ms"] and prev["response_ms"] > s["alert_latency_ms"]):
        db.add_alert(now, "warning", "High latency",
                     f"Response time {rec['response_ms']} ms is above the {s['alert_latency_ms']} ms limit.")

    manager.push({"type": "test_result", "data": rec})
    return rec


async def monitor_loop():
    last = 0.0
    while True:
        await asyncio.sleep(1)
        s = db.get_settings()
        if s["auto_monitor"] and time.monotonic() - last >= s["interval_seconds"]:
            last = time.monotonic()
            await asyncio.to_thread(execute_test, "auto")


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()
    manager.loop = asyncio.get_running_loop()
    bridge.start(lambda device: execute_test(f"esp32:{device}"))
    task = asyncio.create_task(monitor_loop())
    yield
    task.cancel()
    bridge.stop()


app = FastAPI(title="NetPulse API", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
                   allow_methods=["*"], allow_headers=["*"])


@app.get("/api/health")
def health():
    return {"status": "ok", "os": platform.system(), "mqtt": {"status": bridge.status, "detail": bridge.detail}}


@app.post("/api/test")
def test_connection():
    return execute_test("dashboard")


@app.get("/api/stats")
def get_stats():
    return db.stats()


@app.get("/api/history")
def get_history(limit: int = 200):
    return db.list_tests(min(max(limit, 1), 1000))


@app.get("/api/alerts")
def get_alerts(limit: int = 50):
    return db.list_alerts(min(max(limit, 1), 200))


@app.post("/api/reset")
def reset():
    db.reset_data()
    manager.push({"type": "reset"})
    return {"ok": True}


class SettingsIn(BaseModel):
    target: Optional[str] = None
    interval_seconds: Optional[int] = None
    auto_monitor: Optional[bool] = None
    timeout_ms: Optional[int] = None
    alert_latency_ms: Optional[int] = None
    source_name: Optional[str] = None
    dest_name: Optional[str] = None
    link_mode: Optional[str] = None


@app.get("/api/settings")
def get_settings():
    return db.get_settings()


@app.put("/api/settings")
def put_settings(body: SettingsIn):
    values = {k: v for k, v in body.model_dump().items() if v is not None}
    try:
        if "target" in values:
            values["target"] = validate_target(values["target"])
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    limits = {"interval_seconds": (5, 3600), "timeout_ms": (500, 10000), "alert_latency_ms": (10, 5000)}
    for key, (lo, hi) in limits.items():
        if key in values and not lo <= values[key] <= hi:
            raise HTTPException(400, f"{key.replace('_', ' ')} must be between {lo} and {hi}")
    for key in ("source_name", "dest_name"):
        if key in values:
            values[key] = values[key].strip()[:40]
            if not values[key]:
                raise HTTPException(400, "Network names cannot be empty")
    if values.get("link_mode") not in (None, "simulated", "wireguard", "vpn"):
        raise HTTPException(400, "Unknown link type")
    db.update_settings(values)
    return db.get_settings()


@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await manager.connect(ws)
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        manager.clients.discard(ws)
