"""Bridge between AWS IoT Core (MQTT) and the NetPulse test engine.

ESP32 publishes  : netpulse/<device>/test/request
Backend replies  : netpulse/<device>/test/result
If the AWS_IOT_* values are missing the bridge stays disabled and NetPulse
still works (dashboard + real ping).
"""
import json
import os
import ssl
import threading

import paho.mqtt.client as mqtt

REQUEST_FILTER = "netpulse/+/test/request"


class MqttBridge:
    def __init__(self):
        self.status = "disabled"
        self.detail = "Set AWS_IOT_* values in backend/.env to enable the ESP32 / AWS IoT link"
        self.client = None
        self.handler = None

    def start(self, handler):
        """handler(device_id) -> test record dict (runs a real ping)."""
        self.handler = handler
        endpoint = os.getenv("AWS_IOT_ENDPOINT", "").strip()
        cert, key, ca = (os.getenv(k, "").strip() for k in ("AWS_IOT_CERT", "AWS_IOT_KEY", "AWS_IOT_CA"))
        if not (endpoint and cert and key and ca):
            return
        for path in (cert, key, ca):
            if not os.path.exists(path):
                self.status, self.detail = "error", f"Certificate file not found: {path}"
                return
        self.client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2,
                                  client_id=os.getenv("AWS_IOT_CLIENT_ID", "netpulse-backend"))
        self.client.tls_set(ca_certs=ca, certfile=cert, keyfile=key, tls_version=ssl.PROTOCOL_TLS_CLIENT)
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.on_message = self._on_message
        self.status, self.detail = "connecting", f"Connecting to {endpoint}"
        self.client.connect_async(endpoint, 8883, keepalive=60)
        self.client.loop_start()

    def stop(self):
        if self.client:
            self.client.loop_stop()
            self.client.disconnect()

    def _on_connect(self, client, userdata, flags, reason_code, properties):
        if reason_code.is_failure:
            self.status, self.detail = "error", f"AWS IoT refused the connection: {reason_code}"
            return
        client.subscribe(REQUEST_FILTER, qos=1)
        self.status, self.detail = "connected", f"Subscribed to {REQUEST_FILTER}"

    def _on_disconnect(self, client, userdata, flags, reason_code, properties):
        self.status, self.detail = "connecting", "Disconnected, retrying..."

    def _on_message(self, client, userdata, msg):
        threading.Thread(target=self._handle, args=(msg,), daemon=True).start()

    def _handle(self, msg):
        parts = msg.topic.split("/")
        if len(parts) != 4:
            return
        device = parts[1]
        try:
            request_id = str(json.loads(msg.payload).get("request_id", ""))
        except (ValueError, AttributeError):
            request_id = ""
        rec = self.handler(device)
        reply = {
            "request_id": request_id, "device": device,
            "connected": bool(rec["reachable"]), "response_ms": rec["response_ms"],
            "target": rec["target"], "ts": rec["ts"],
        }
        self.client.publish(f"netpulse/{device}/test/result",
                            json.dumps(reply, separators=(",", ":")), qos=1)


bridge = MqttBridge()
