/*
  NetPulse ESP32 firmware
  Button press -> MQTT request to AWS IoT Core -> backend pings target -> result comes back
  -> green LED (connected) or red LED (disconnected).

  Libraries (Arduino IDE > Library Manager): "PubSubClient" by Nick O'Leary
  Board: "ESP32 Dev Module"  (install "esp32 by Espressif" in Boards Manager)

  Setup: copy secrets.example.h to secrets.h and fill it in. secrets.h is git-ignored.
*/
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include "secrets.h"

// ---- Pins (see docs/01_design.md for the wiring diagram) ----
const int PIN_BUTTON = 4;    // button between GPIO4 and GND (internal pull-up used)
const int PIN_GREEN  = 26;   // GPIO26 -> 220 ohm -> green LED -> GND
const int PIN_RED    = 27;   // GPIO27 -> 220 ohm -> red LED   -> GND

const char* DEVICE_ID = "esp32-01";          // must match the Thing name + IoT policy
const unsigned long RESULT_TIMEOUT_MS = 15000;

String topicRequest = String("netpulse/") + DEVICE_ID + "/test/request";
String topicResult  = String("netpulse/") + DEVICE_ID + "/test/result";

WiFiClientSecure net;
PubSubClient mqtt(net);

bool waiting = false;
unsigned long sentAt = 0;
String requestId;

void leds(bool green, bool red) {
  digitalWrite(PIN_GREEN, green);
  digitalWrite(PIN_RED, red);
}

void blinkBoth(int times) {
  for (int i = 0; i < times; i++) { leds(true, true); delay(120); leds(false, false); delay(120); }
}

// Called when a message arrives on netpulse/<device>/test/result
void onMessage(char* topic, byte* payload, unsigned int length) {
  String msg;
  for (unsigned int i = 0; i < length; i++) msg += (char)payload[i];
  Serial.println("Result: " + msg);

  if (!waiting || msg.indexOf("\"request_id\":\"" + requestId + "\"") < 0) return;  // not our request
  waiting = false;

  if (msg.indexOf("\"connected\":true") >= 0) { leds(true, false); Serial.println("CONNECTED -> green LED"); }
  else                                         { leds(false, true); Serial.println("DISCONNECTED -> red LED"); }
}

void connectWifi() {
  Serial.print("WiFi");
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) { delay(400); Serial.print("."); digitalWrite(PIN_RED, !digitalRead(PIN_RED)); }
  digitalWrite(PIN_RED, LOW);
  Serial.println(" connected, IP " + WiFi.localIP().toString());
}

// TLS certificates are only valid at certain dates, so the ESP32 needs the real time.
void syncClock() {
  configTime(0, 0, "pool.ntp.org", "time.nist.gov");
  Serial.print("Clock");
  time_t now = time(nullptr);
  while (now < 1700000000) { delay(300); Serial.print("."); now = time(nullptr); }
  Serial.println(" synced");
}

void connectMqtt() {
  while (!mqtt.connected()) {
    Serial.print("AWS IoT...");
    if (mqtt.connect(DEVICE_ID)) {
      mqtt.subscribe(topicResult.c_str(), 1);
      Serial.println(" connected");
      blinkBoth(2);
    } else {
      Serial.printf(" failed (state %d), retry in 3 s\n", mqtt.state());
      delay(3000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_BUTTON, INPUT_PULLUP);
  pinMode(PIN_GREEN, OUTPUT);
  pinMode(PIN_RED, OUTPUT);
  blinkBoth(3);                      // power-on self test

  connectWifi();
  syncClock();

  net.setCACert(AWS_ROOT_CA);
  net.setCertificate(DEVICE_CERT);
  net.setPrivateKey(DEVICE_KEY);
  mqtt.setServer(AWS_ENDPOINT, 8883);
  mqtt.setCallback(onMessage);
  mqtt.setBufferSize(512);
}

void sendRequest() {
  requestId = String(millis());
  String body = "{\"request_id\":\"" + requestId + "\",\"device\":\"" + DEVICE_ID + "\"}";
  if (mqtt.publish(topicRequest.c_str(), body.c_str())) {
    Serial.println("Request sent: " + body);
    waiting = true;
    sentAt = millis();
  } else {
    Serial.println("Publish failed");
    leds(false, true);
  }
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) connectWifi();
  if (!mqtt.connected()) connectMqtt();
  mqtt.loop();

  // Button with simple debounce
  static bool lastState = HIGH;
  static unsigned long lastChange = 0;
  bool state = digitalRead(PIN_BUTTON);
  if (state != lastState && millis() - lastChange > 50) {
    lastChange = millis();
    lastState = state;
    if (state == LOW && !waiting) sendRequest();
  }

  // While waiting: blink both LEDs. Give up after the timeout.
  if (waiting) {
    leds((millis() / 250) % 2, (millis() / 250) % 2);
    if (millis() - sentAt > RESULT_TIMEOUT_MS) {
      waiting = false;
      leds(false, true);
      Serial.println("No answer from backend -> red LED");
    }
  }
}
