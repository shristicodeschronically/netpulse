// Copy this file to secrets.h and fill it in. NEVER commit secrets.h or share it.
#pragma once

#define WIFI_SSID     "your-wifi-name"
#define WIFI_PASSWORD "your-wifi-password"

// AWS IoT Core > Settings > Device data endpoint
#define AWS_ENDPOINT  "xxxxxxxxxxxxxx-ats.iot.ap-south-1.amazonaws.com"

// Paste the full contents of each file between the markers (keep the BEGIN/END lines).
static const char AWS_ROOT_CA[] PROGMEM = R"EOF(
-----BEGIN CERTIFICATE-----
(AmazonRootCA1.pem)
-----END CERTIFICATE-----
)EOF";

static const char DEVICE_CERT[] PROGMEM = R"EOF(
-----BEGIN CERTIFICATE-----
(esp32.cert.pem)
-----END CERTIFICATE-----
)EOF";

static const char DEVICE_KEY[] PROGMEM = R"EOF(
-----BEGIN RSA PRIVATE KEY-----
(esp32.private.key)
-----END RSA PRIVATE KEY-----
)EOF";
